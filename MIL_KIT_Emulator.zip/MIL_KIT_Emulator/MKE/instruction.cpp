#include "instruction.h"

instruction::instruction()
{
    ins="\0";
    address=0x0000;

}
