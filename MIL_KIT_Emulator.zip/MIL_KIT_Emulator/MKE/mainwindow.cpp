#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <chip_8251.h>
#include<instruction.h>


chip_8251 obj;
unsigned long counter;
instruction code_array[200];
int i=0,previous_return=-1;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
     ui->setupUi(this);
     //ui->terminal->setCursorPosition(1);
     ui->terminal->setFocus();
     QFont font;
     font.setCapitalization(QFont::AllUppercase);
     ui->terminal->setFont(font);
    ui->display_terminal->setFont(font);
     connect(ui->terminal,SIGNAL(returnPressed()),this,SLOT(on_ENTER_pressed())) ;
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_reset_clicked()
{
    ui->terminal->setFocus();
}

void MainWindow::on_ENTER_pressed()
{
    QString command=ui->terminal->text().toUpper();
    instruction ob;
    ui->terminal->clear();
    QStringList list;
    list=command.split(QRegExp(",| "));
    if (list.at(0)=="A")
    {   bool ok;
        counter=list.at(1).toULong(&ok,16);
    }
    else if(list.at(0)=="G")
    {   bool ok;
      instruction_fetch(list.at(1).toULong(&ok,16));
    }
    counter++;
    ob.address=counter++;
    ob.ins=command;
    code_array[i]=ob;
    ui->display_terminal->append("0000:"+QString::number(code_array[i].address,16)+" "+code_array[i].ins);
    i++;


}


void MainWindow::instruction_fetch(unsigned long addr)
{   for(int j=0;j<i;j++)
    {
        if (code_array[j].address==addr)
        {   ui->cwa->setText(obj.CW_A_31);
            ui->dpa->setText(obj.DP_A_30);
            ui->cwb->setText(obj.CW_B_29);
            ui->dpb->setText(obj.DP_B_28);
            ui->al->setText(obj.al);
            QStringList list;
            list=code_array[j].ins.split(QRegExp(",| "));
            if (list.at(0)=="A")
            {bool ok;
            counter=list.at(1).toULong(&ok,16);

            }
            else if(list.at(0)=="MOV")
            {
                if(list.at(1)=="AL"||list.at(1)=="BL"||list.at(1)=="CL"||list.at(1)=="DL")
                {   obj.mov(list.at(1),list.at(2));
                }
            }
            else if(list.at(0)=="OUT")
            {
                obj.out(list.at(1),list.at(2));
            }
            else if(list.at(0)=="TEST")
            {
                obj.test(list.at(1),list.at(2));
            }
            else if(list.at(0)=="INT")
            {
               return;
            }
            else if(list.at(0)=="JZ")
            {   bool ok;
                if(previous_return==0)
                {
                    instruction_fetch(list.at(1).toULong(&ok,16));
                }

            }
            while(list.at(0)!="INT")
            {
            instruction_fetch(addr=addr+2);
            }

        }
    }



}
